# monte-carlo-radiation-simulator

A lightweight educational Python project that models photon transport through layered tissue using a simple Monte Carlo approach.
This starter version is intentionally simplified to demonstrate core ideas (free path sampling, simple interaction types, and dose tallying).

Run the demo to see a quick dose-vs-depth result and explore the `src/` files to expand the physics later.