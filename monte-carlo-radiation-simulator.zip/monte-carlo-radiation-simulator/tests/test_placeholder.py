
# tests are left for you to expand. Examples:
# - test sampling distribution for sample_free_path
# - test energy normalization after a single-step Compton in your physics module
