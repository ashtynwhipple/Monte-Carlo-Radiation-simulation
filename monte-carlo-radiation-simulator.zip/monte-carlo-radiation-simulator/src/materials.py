
# Materials and layer definitions for the demo.
# Thickness in cm, density in g/cm^3, linear attenuation mu in 1/cm (simplified/example values).
layers = [
    { "name": "skin",   "thickness_cm": 0.2, "density_g_cm3": 1.10, "mu_cm": 0.20 },
    { "name": "fat",    "thickness_cm": 1.0, "density_g_cm3": 0.90, "mu_cm": 0.15 },
    { "name": "muscle", "thickness_cm": 3.0, "density_g_cm3": 1.06, "mu_cm": 0.18 },
    { "name": "bone",   "thickness_cm": 0.5, "density_g_cm3": 1.85, "mu_cm": 0.50 },
]
