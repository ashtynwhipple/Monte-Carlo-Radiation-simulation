
from src.simulate import run_simulation
from src.dosimetry import energy_keV_to_Gy
from src.materials import layers
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os

N = 10000
E0 = 120.0  # keV
bin_thickness = 0.1  # cm

bins_keV, nbins, bin_thickness = run_simulation(N_photons=N, E0_keV=E0, bin_thickness_cm=bin_thickness)
dose = energy_keV_to_Gy(bins_keV, bin_thickness, nbins)

depths = (np.arange(nbins) + 0.5) * bin_thickness  # cm (bin centers)
df = pd.DataFrame({ 'depth_cm': depths, 'dose_Gy': dose, 'energy_keV_deposited': bins_keV })

outdir = '/mnt/data/monte-carlo-radiation-simulator/results/dose_profiles'
os.makedirs(outdir, exist_ok=True)
csv_path = os.path.join(outdir, f'dose_profile_N{N}_E{int(E0)}keV.csv')
png_path = os.path.join(outdir, f'dose_profile_N{N}_E{int(E0)}keV.png')

df.to_csv(csv_path, index=False)

plt.figure(figsize=(6,3))
plt.plot(df['depth_cm'], df['dose_Gy'])
plt.xlabel('Depth (cm)')
plt.ylabel('Dose (Gy)')
plt.title(f'Dose vs Depth (N={N}, E={int(E0)} keV)')
plt.tight_layout()
plt.savefig(png_path)
plt.close()

# report back paths and a small sample
print(csv_path)
print(png_path)
print(df.head().to_string(index=False))
