
import numpy as np
from src.materials import layers

# convert deposited energy (keV) per bin into dose (Gy)
# assumptions: unit area = 1 cm^2 for each bin. mass of bin = density (g/cm^3) * volume (cm^3) -> convert to kg
EV_TO_J = 1.602176634e-19 * 1000.0  # 1 keV = 1e3 eV; 1 eV = 1.602e-19 J

def energy_keV_to_Gy(energy_keV_array, bin_thickness_cm, nbins):
    # create depth->density mapping per bin by walking layers
    densities = np.zeros(nbins, dtype=float)
    pos = 0.0
    bin_idx = 0
    layer_idx = 0
    for bin_idx in range(nbins):
        depth = bin_idx * bin_thickness_cm + 0.5 * bin_thickness_cm
        # find layer containing this depth
        pos = 0.0
        for L in layers:
            if pos <= depth < pos + L['thickness_cm']:
                densities[bin_idx] = L['density_g_cm3']
                break
            pos += L['thickness_cm']
    # compute mass per bin (kg) assuming 1 cm^2 area -> volume = bin_thickness_cm * 1 cm^2
    volumes_cm3 = np.ones(nbins) * bin_thickness_cm * 1.0
    masses_kg = densities * volumes_cm3 / 1000.0  # g -> kg
    energy_J = energy_keV_array * EV_TO_J
    dose_Gy = energy_J / masses_kg
    return dose_Gy
