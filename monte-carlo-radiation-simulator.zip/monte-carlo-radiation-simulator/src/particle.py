
# Minimal photon representation for the demo.
class Photon:
    def __init__(self, energy_keV, position_cm=0.0, direction=1):
        self.energy_keV = energy_keV
        self.position_cm = position_cm
        self.direction = direction  # +1 means moving into tissue (increasing depth)
        self.alive = True
