
import random, math
import numpy as np
from src.particle import Photon
from src.materials import layers

# Simple helpers
def find_layer(depth_cm):
    pos = 0.0
    for L in layers:
        if pos <= depth_cm < pos + L['thickness_cm']:
            return L, pos
        pos += L['thickness_cm']
    return None, pos

def sample_free_path(mu_cm):
    r = random.random()
    return -math.log(r) / mu_cm

def run_simulation(N_photons=10000, E0_keV=120.0, bin_thickness_cm=0.1):
    total_depth = sum(L['thickness_cm'] for L in layers)
    nbins = int(math.ceil(total_depth / bin_thickness_cm))
    bins = np.zeros(nbins, dtype=float)  # energy deposited (keV)
    # simplified physics probabilities (example):
    # photoelectric probability and compton probability (energy-dependent in reality)
    # here we set them to fixed example fractions for demonstration
    p_photo = 0.10
    p_compton = 0.90
    for i in range(N_photons):
        ph = Photon(E0_keV, position_cm=0.0, direction=1)
        while ph.alive and ph.energy_keV > 1.0:  # simple cutoff
            L, layer_start = find_layer(ph.position_cm)
            if L is None:
                break  # photon left geometry
            mu = L['mu_cm']
            # sample free path
            s = sample_free_path(mu)
            new_pos = ph.position_cm + ph.direction * s
            # if moves out of geometry, stop tracking
            if new_pos >= sum(l['thickness_cm'] for l in layers):
                break
            # determine bin index where interaction occurs
            bin_idx = int(new_pos // bin_thickness_cm)
            # choose interaction type
            if random.random() < p_photo:
                # photoelectric: deposit entire remaining energy here and kill photon
                bins[bin_idx] += ph.energy_keV
                ph.alive = False
            else:
                # Compton: deposit a fraction locally, reduce photon energy and continue
                deposit_fraction = 0.20  # example simplified fraction
                deposited = ph.energy_keV * deposit_fraction
                bins[bin_idx] += deposited
                ph.energy_keV *= (1.0 - deposit_fraction)
                # continue tracking (direction unchanged in this simplified demo)
    return bins, nbins, bin_thickness_cm
